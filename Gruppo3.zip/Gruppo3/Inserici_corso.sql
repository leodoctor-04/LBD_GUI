create or replace procedure creaCorso( p_idSessione IN NUMBER DEFAULT -1, p_filtro IN NUMBER DEFAULT NULL ) is
BEGIN
  baseHTML.apriPagina('Crea corso', p_idSessione);

        Corsi.moduloInserisciCorso;

    baseHTML.chiudiPagina;

end creaCorso;
/
GRANT EXECUTE ON creaCorso TO anonymous;