create or replace package Corsi as

-- visualizza i corsi,
-- se tipologia è null mostra tutto, altrimenti mostra solo quelli della tipologia (ATTENZIONE al case sensitive)
-- per mostrare tutti i corsi di una tipologia, metterenumero a null, e scrivere la tipologia desiderata
procedure visualizzaCorsi(
    p_tipologia IN varchar2 DEFAULT NULL,  -- case sensitive
    useSessione BOOLEAN default TRUE
);
PROCEDURE visualizzaCorsiIstruttore(
    p_idIstruttore IN number
);

-- visualizza tutti i dettagli di un corso specifico
procedure visualizzaCorso(
    p_id IN number DEFAULT NULL  -- case sensitive
);

PROCEDURE inserisciCorso(
    p_idSessione IN NUMBER DEFAULT -1,
    p_titolo IN corso.titolo%TYPE,
    p_descrizione IN corso.descrizione%TYPE,
    p_durata IN corso.durata%TYPE,
    p_maxPartecipanti IN corso.maxPartecipanti%TYPE,
    p_prezzo IN corso.prezzo%TYPE,

    p_idtipologia IN corso.idtipologia%TYPE,
    p_idIstruttore IN corso.idIstruttore%TYPE
);

PROCEDURE moduloInserisciCorso;

PROCEDURE degradaCorso( p_id IN number );

PROCEDURE votoCorso( p_id IN number );

end Corsi;
